<?php
class _404 extends Controller
{
    public function index($a = '', $b = '', $c = '')
    {
        echo "404 Page Not Found controller";
    }
}




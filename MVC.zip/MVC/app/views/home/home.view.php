<h1> Home file view</h1>
<img src="<?= ROOT ?>/assets/images/logo.JPG">
<link rel="stylesheet" href="<?= ROOT ?>/assets/css/home.css">